package com.cody.ide;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import com.cody.ide.core.presenter.MainPresenter;
import com.cody.ide.core.view.MainView;
import com.cody.ide.theme.ThemeManager;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Wisdom Code Editor");

        // Initialize the main view
        MainView mainView = new MainView();

        // Set up the scene with the main view
        Scene scene = new Scene(mainView.getRoot(), 800, 600);

        // Apply the initial theme and register the scene
        ThemeManager.applyInitialTheme(scene);

        // Initialize the main presenter with the main view and primary stage
        MainPresenter mainPresenter = new MainPresenter(mainView, primaryStage);

        primaryStage.setScene(scene);
        primaryStage.show();

        // Example of updating the status bar
        mainPresenter.getStatusBarPresenter().updateStatus("Application started");
    }

    public static void main(String[] args) {
        launch(args);
    }
}

package com.cody.ide.core.component.CodeEditor;

public class MonacoPresenter {
    private MonacoView monacoView;

    public MonacoPresenter(MonacoView monacoView) {
        this.monacoView = monacoView;
        initialize();
    }

    private void initialize() {
        // Set up initial configuration for Monaco editor
        monacoView.getMonacoFX().getEditor().setCurrentLanguage("java");
        monacoView.getMonacoFX().getEditor().setCurrentTheme("vs-light");
    }

    public void setEditorContent(String content) {
        monacoView.getMonacoFX().getEditor().getDocument().setText(content);
    }

    public String getEditorContent() {
        return monacoView.getMonacoFX().getEditor().getDocument().getText();

    }

    public String getEditorLanguage() {
        if (monacoView == null || monacoView.getMonacoFX() == null || monacoView.getMonacoFX().getEditor() == null) {
            System.out.println("Warning: MonacoFX editor not properly initialized");
            return null;
        }
        String language = monacoView.getMonacoFX().getEditor().getCurrentLanguage();
        System.out.println("Current editor language: " + language);
        return language;
    }
}

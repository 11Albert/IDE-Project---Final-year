package com.cody.ide.core.component.CodeEditor;

import eu.mihosoft.monacofx.MonacoFX;
import javafx.scene.layout.StackPane;

public class MonacoView {
    private MonacoFX monacoFX;
    private StackPane root;

    public MonacoView() {
        monacoFX = new MonacoFX();
        root = new StackPane(monacoFX);
    }

    public StackPane getRoot() {
        return root;
    }

    public MonacoFX getMonacoFX() {
        return monacoFX;
    }
}

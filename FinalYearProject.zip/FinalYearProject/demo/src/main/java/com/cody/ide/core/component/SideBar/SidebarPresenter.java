package com.cody.ide.core.component.SideBar;

public class SidebarPresenter {

    private SidebarView sidebarView;

    public SidebarPresenter(SidebarView sidebarView) {
        this.sidebarView = sidebarView;
        initialize();
    }

    private void initialize() {
        // Initialize the sidebar with default items or logic
    }

    public SidebarView getSidebarView() {
        return sidebarView;
    }

    public void addItem(javafx.scene.Node item) {
        sidebarView.addItem(item);
    }
}

package com.cody.ide.core.component.SideBar;

import javafx.geometry.Orientation;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class SidebarView {

    private ToolBar root;

    public SidebarView() {
        root = new ToolBar();
        root.setOrientation(Orientation.VERTICAL);

        // Spacer to push content to the top
        VBox spacer = new VBox();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        root.getItems().add(spacer);
    }

    public ToolBar getRoot() {
        return root;
    }

    public void addItem(javafx.scene.Node item) {
        int insertIndex = root.getItems().size() - 1; // Calculate the correct index
        if (insertIndex < 0) {
            insertIndex = 0; // Ensure the index is not negative
        }
        root.getItems().add(insertIndex, item); // Add before the spacer
    }
}

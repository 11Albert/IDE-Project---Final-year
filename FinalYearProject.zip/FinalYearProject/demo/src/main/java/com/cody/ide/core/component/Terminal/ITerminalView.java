package com.cody.ide.core.component.Terminal;

import pk.jeditermfx.ui.JediTermFxWidget;
import javafx.scene.layout.StackPane;

public interface ITerminalView {
    JediTermFxWidget getTerminalWidget();
    void start();
    void close();
    void writeCommand(String command);
    StackPane getRoot(); // Add this method
}

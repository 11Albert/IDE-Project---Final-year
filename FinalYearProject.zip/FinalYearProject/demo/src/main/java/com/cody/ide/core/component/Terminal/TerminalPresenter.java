package com.cody.ide.core.component.Terminal;

import pk.jeditermfx.app.pty.PtyProcessTtyConnector;
import pk.jeditermfx.core.TtyConnector;
import com.pty4j.PtyProcess;
import com.pty4j.PtyProcessBuilder;
import org.jetbrains.annotations.NotNull;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import pk.jeditermfx.core.util.Platform;
import java.io.IOException;

public class TerminalPresenter {
    private TerminalView terminalView;

    public TerminalPresenter(TerminalView terminalView) {
        this.terminalView = terminalView;
        initialize();
    }

    private void initialize() {
        terminalView.getTerminalWidget().setTtyConnector(createTtyConnector());
        terminalView.start();
    }

    private @NotNull TtyConnector createTtyConnector() {
        try {
            Map<String, String> envs = System.getenv();
            String[] command;
            if (Platform.isWindows()) {
                command = new String[]{"cmd.exe"};
            } else {
                command = new String[]{"/bin/bash", "--login"};
                envs = new HashMap<>(System.getenv());
                envs.put("TERM", "xterm-256color");
            }
            PtyProcess process = new PtyProcessBuilder().setCommand(command).setEnvironment(envs).start();
            return new PtyProcessTtyConnector(process, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public void closeTerminal() {
        terminalView.close();
    }

    public void writeAndExecuteCommand(String command) {
        terminalView.writeCommand(command);
    }

    public void writeFormattedCommand(String command, String color) {
        try {
            TtyConnector connector = terminalView.getTerminalWidget().getTtyConnector();
            connector.write("\u001B[" + color + "m" + command + "\u001B[0m\r\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package com.cody.ide.core.component.Terminal;

import pk.jeditermfx.ui.JediTermFxWidget;
import pk.jeditermfx.ui.settings.DefaultSettingsProvider;
import javafx.scene.layout.StackPane;
import java.io.IOException;

public class TerminalView implements ITerminalView {
    private JediTermFxWidget terminal;
    private StackPane root;

    public TerminalView() {
        terminal = new JediTermFxWidget(80, 24, new DefaultSettingsProvider());
        root = new StackPane();
        root.getChildren().add(terminal.getPane());
    }

    @Override
    public StackPane getRoot() {
        return root;
    }

    @Override
    public JediTermFxWidget getTerminalWidget() {
        return terminal;
    }

    @Override
    public void start() {
        terminal.start();
    }

    @Override
    public void close() {
        terminal.close();
    }

    @Override
    public void writeCommand(String command) {
        try {
            terminal.getTtyConnector().write(command + "\r\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

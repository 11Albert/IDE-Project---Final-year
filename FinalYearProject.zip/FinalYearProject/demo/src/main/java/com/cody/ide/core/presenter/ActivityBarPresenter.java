package com.cody.ide.core.presenter;

import com.cody.ide.core.view.ActivityBarView;
import com.cody.ide.core.view.WorkspaceView;
import com.cody.ide.core.view.ActivityPanel.ActivityPanelManager;
import javafx.scene.control.Button;

public class ActivityBarPresenter {

    private ActivityBarView activityBarView;
    private WorkspaceView workspaceView;
    private ActivityPanelManager activityPanelManager;

    public ActivityBarPresenter(ActivityBarView activityBarView, WorkspaceView workspaceView) {
        this.activityBarView = activityBarView;
        this.workspaceView = workspaceView;
        this.activityPanelManager = new ActivityPanelManager(workspaceView.getSidebarView());
        initialize();
    }

    private void initialize() {
        Button explorerButton = activityBarView.getExplorerButton();
        Button searchButton = activityBarView.getSearchButton();
        Button accountButton = activityBarView.getAccountButton();
        Button manageButton = activityBarView.getManageButton();

        explorerButton.setOnAction(event -> toggleSidebar("explorer"));
        searchButton.setOnAction(event -> toggleSidebar("search"));
        accountButton.setOnAction(event -> showAccountMenu());
        manageButton.setOnAction(event -> showManageMenu());
    }

    private void toggleSidebar(String view) {
        switch (view) {
            case "explorer":
                activityPanelManager.toggleExplorerView();
                break;
            case "search":
                activityPanelManager.toggleSearchView();
                break;
            default:
                System.out.println("Invalid view: " + view);
        }

        // Update the workspace view if necessary
        if (!workspaceView.getRoot().getItems().contains(workspaceView.getSidebarView().getRoot())) {
            workspaceView.getRoot().getItems().add(0, workspaceView.getSidebarView().getRoot());
        } else if (activityPanelManager.getCurrentView() == null) {
            workspaceView.getRoot().getItems().remove(workspaceView.getSidebarView().getRoot());
        }
    }

    private void showAccountMenu() {
        // Logic to show the account context menu
        System.out.println("Account menu shown");
    }

    private void showManageMenu() {
        // Logic to show the manage context menu
        System.out.println("Manage menu shown");
    }

    public ActivityBarView getActivityBarView() {
        return activityBarView;
    }

    public ActivityPanelManager getActivityPanelManager() {
        return activityPanelManager;
    }
}

package com.cody.ide.core.presenter;

import com.cody.ide.core.view.MainView;
import com.cody.ide.core.view.TopBarView;
import com.cody.ide.core.view.StatusBarView;
import com.cody.ide.core.view.ActivityBarView;
import com.cody.ide.core.view.WorkspaceView;
import com.cody.ide.core.component.SideBar.SidebarPresenter;
import com.cody.ide.core.component.CodeEditor.MonacoPresenter;
import com.cody.ide.core.component.Terminal.TerminalPresenter;
import javafx.scene.Scene;
import javafx.stage.Stage;
import atlantafx.base.theme.*;

public class MainPresenter {

    private Theme currentTheme = new PrimerLight();
    private MainView mainView;
    private StatusBarPresenter statusBarPresenter;
    private ActivityBarPresenter activityBarPresenter;
    private WorkspacePresenter workspacePresenter;
    private SidebarPresenter sidebarPresenter;
    private Stage primaryStage;
    private TopBarPresenter topBarPresenter;
    private MonacoPresenter monacoPresenter;
    private TerminalPresenter terminalPresenter;

    public MainPresenter(MainView mainView, Stage primaryStage) {
        this.mainView = mainView;
        this.primaryStage = primaryStage;
        initializePresenters();
    }

    private void initializePresenters() {
        this.statusBarPresenter = new StatusBarPresenter(mainView.getStatusBarView());
        this.activityBarPresenter = new ActivityBarPresenter(mainView.getActivityBarView(), mainView.getWorkspaceView());
        this.workspacePresenter = new WorkspacePresenter(mainView.getWorkspaceView());
        this.sidebarPresenter = new SidebarPresenter(mainView.getWorkspaceView().getSidebarView());
        this.topBarPresenter = new TopBarPresenter(mainView.getTopBarView(), activityBarPresenter.getActivityPanelManager().getExplorerView(), primaryStage, this);
        this.monacoPresenter = workspacePresenter.getMonacoPresenter();
        this.terminalPresenter = workspacePresenter.getTerminalPresenter();
    }

    public void applyInitialTheme(Scene scene) {
        applyTheme(scene);
    }

    public void switchTheme(Scene scene) {
        if (currentTheme instanceof PrimerLight) {
            currentTheme = new PrimerDark();
        } else if (currentTheme instanceof PrimerDark) {
            currentTheme = new NordLight();
        } else if (currentTheme instanceof NordLight) {
            currentTheme = new NordDark();
        } else if (currentTheme instanceof NordDark) {
            currentTheme = new CupertinoLight();
        } else if (currentTheme instanceof CupertinoLight) {
            currentTheme = new CupertinoDark();
        } else if (currentTheme instanceof CupertinoDark) {
            currentTheme = new Dracula();
        } else {
            currentTheme = new PrimerLight();
        }

        applyTheme(scene);
    }

    private void applyTheme(Scene scene) {
        // Clear existing stylesheets
        scene.getStylesheets().clear();

        // Apply the selected theme
        scene.getStylesheets().add(currentTheme.getUserAgentStylesheet());

        // Load your custom CSS
        scene.getStylesheets().add(getClass().getResource("/themes/styles.css").toExternalForm());
    }

    public StatusBarPresenter getStatusBarPresenter() {
        return statusBarPresenter;
    }

    public MonacoPresenter getMonacoPresenter() {
        return monacoPresenter;
    }

    public TerminalPresenter getTerminalPresenter() {
        return terminalPresenter;
    }
}

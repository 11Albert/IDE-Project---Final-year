package com.cody.ide.core.presenter;

import com.cody.ide.core.view.StatusBarView;

public class StatusBarPresenter {

    private StatusBarView statusBarView;

    public StatusBarPresenter(StatusBarView statusBarView) {
        this.statusBarView = statusBarView;
    }

    public void updateStatus(String status) {
        statusBarView.setStatus(status);
    }

    public StatusBarView getStatusBarView() {
        return statusBarView;
    }
}

package com.cody.ide.core.presenter;

import com.cody.ide.core.view.TopBarView;
import com.cody.ide.theme.ThemeManager;
import com.cody.ide.core.view.ActivityPanel.Explorer.ExplorerView;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.HBox;
import javafx.geometry.Orientation;
import javafx.stage.FileChooser;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.kordamp.ikonli.material2.Material2OutlinedAL;
import atlantafx.base.controls.CaptionMenuItem;
import net.datafaker.Faker;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class TopBarPresenter {

    private TopBarView topBarView;
    private static final Faker FAKER = new Faker();
    private ExplorerView explorerView;
    private Stage primaryStage;
    private MainPresenter mainPresenter;
    private List<String> tempFileNames;

    public TopBarPresenter(TopBarView topBarView, ExplorerView explorerView, Stage primaryStage, MainPresenter mainPresenter) {
        this.topBarView = topBarView;
        this.explorerView = explorerView;
        this.primaryStage = primaryStage;
        this.mainPresenter = mainPresenter;
        this.tempFileNames = new ArrayList<>();
        initialize();
    }

    private void initialize() {
        setupMenuBar();
        setupToolBar();
    }

    private void setupMenuBar() {
        Menu fileMenu = new Menu("_File");
        fileMenu.setMnemonicParsing(true);
        fileMenu.getItems().addAll(
            createItem("_New", null, new KeyCodeCombination(KeyCode.N, KeyCombination.CONTROL_DOWN)),
            new SeparatorMenuItem(),
            createItem("Open File", Feather.FILE, new KeyCodeCombination(KeyCode.O, KeyCombination.CONTROL_DOWN)),
            createItem("Open Folder", Feather.FOLDER, new KeyCodeCombination(KeyCode.F, KeyCombination.CONTROL_DOWN)),
            createOpenRecentMenu(),
            new SeparatorMenuItem(),
            createItem("Save", Feather.SAVE, new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN)),
            new MenuItem("Save As"),
            new SeparatorMenuItem(),
            createPreferencesMenu(),
            new MenuItem("Exit")
        );

        // Set actions for Open File and Open Folder
        fileMenu.getItems().stream()
            .filter(item -> item.getText() != null)
            .forEach(item -> {
                if (item.getText().equals("Open File")) {
                    item.setOnAction(event -> openFile());
                } else if (item.getText().equals("Open Folder")) {
                    item.setOnAction(event -> openFolder());
                }
            });

        Menu editMenu = new Menu("_Edit");
        editMenu.setMnemonicParsing(true);
        editMenu.getItems().addAll(
            createItem("Undo", Feather.CORNER_DOWN_LEFT, new KeyCodeCombination(KeyCode.Z, KeyCombination.CONTROL_DOWN)),
            createItem("Redo", Feather.CORNER_DOWN_RIGHT, new KeyCodeCombination(KeyCode.Y, KeyCombination.CONTROL_DOWN)),
            new SeparatorMenuItem(),
            createItem("Cut", Feather.SCISSORS, new KeyCodeCombination(KeyCode.X, KeyCombination.CONTROL_DOWN)),
            createItem("Copy", Feather.COPY, new KeyCodeCombination(KeyCode.C, KeyCombination.CONTROL_DOWN)),
            createItem("Paste", Feather.CORNER_DOWN_LEFT, new KeyCodeCombination(KeyCode.V, KeyCombination.CONTROL_DOWN))
        );

        Menu viewMenu = new Menu("_View");
        viewMenu.setMnemonicParsing(true);
        CheckMenuItem showToolbarItem = createCheckMenuItem("Show Toolbar", Feather.TOOL, new KeyCodeCombination(KeyCode.T, KeyCombination.CONTROL_DOWN));
        showToolbarItem.setSelected(true);
        showToolbarItem.setOnAction(event -> topBarView.setToolBarVisible(showToolbarItem.isSelected()));

        viewMenu.getItems().addAll(
            showToolbarItem,
            createCheckMenuItem("Show Grid", Feather.GRID, null),
            new SeparatorMenuItem(),
            new CaptionMenuItem("Layout"),
            createRadioMenuItem("Single", Material2OutlinedAL.LOOKS_ONE, true),
            createRadioMenuItem("Two Columns", Material2OutlinedAL.LOOKS_TWO, false),
            createRadioMenuItem("Three Columns", Material2OutlinedAL.LOOKS_3, false)
        );

        Menu toolsMenu = new Menu("_Tools");
        toolsMenu.setMnemonicParsing(true);
        toolsMenu.setDisable(true);

        Menu aboutMenu = new Menu("_About", new FontIcon(Feather.HELP_CIRCLE));
        aboutMenu.setMnemonicParsing(true);
        aboutMenu.getItems().addAll(
            new MenuItem("Help"),
            new MenuItem("About"),
            new SeparatorMenuItem(),
            createDeeplyNestedMenu()
        );

        topBarView.getMenuBar().getMenus().addAll(fileMenu, editMenu, viewMenu, toolsMenu, aboutMenu);
    }

    private void setupToolBar() {
        ToolBar toolBar = topBarView.getToolBar();

        // File operation buttons
        Button newButton = new Button("New", new FontIcon(Feather.PLUS));
        Button openButton = new Button("Open", new FontIcon(Feather.FILE));
        Button saveButton = new Button("Save", new FontIcon(Feather.SAVE));

        // Set actions for Open button
        openButton.setOnAction(event -> openFile());

        // Separator to distinguish between file and code operations
        Separator fileCodeSeparator = new Separator();
        fileCodeSeparator.setOrientation(Orientation.VERTICAL);

        // Code operation buttons
        Button cleanButton = new Button("Clean", new FontIcon(Feather.ROTATE_CCW));
        Button compileButton = new Button("Compile", new FontIcon(Feather.LAYERS));
        Button runButton = new Button("Run", new FontIcon(Feather.PLAY));

        // Set action for Run button
        runButton.setOnAction(event -> runCode());

        // Separator to distinguish between code operations and spacer
        Separator codeSpacerSeparator = new Separator();
        codeSpacerSeparator.setOrientation(Orientation.VERTICAL);

        // Spacer to push code operation buttons to the right
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Add buttons to the toolbar
        toolBar.getItems().addAll(newButton, openButton, saveButton, fileCodeSeparator, spacer, codeSpacerSeparator, cleanButton, compileButton, runButton);
    }

    private void openFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open File");
        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null) {
            explorerView.addFileToTree(selectedFile);
        }
    }

    private void openFolder() {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        directoryChooser.setTitle("Open Folder");
        File selectedDirectory = directoryChooser.showDialog(primaryStage);
        if (selectedDirectory != null) {
            explorerView.addFolderToTree(selectedDirectory);
        }
    }

    private Menu createOpenRecentMenu() {
        Menu openRecentMenu = new Menu("Open _Recent");
        openRecentMenu.setMnemonicParsing(true);
        openRecentMenu.getItems().addAll(
            IntStream.range(0, 10)
                .mapToObj(x -> new MenuItem(FAKER.file().fileName()))
                .collect(Collectors.toList())
        );
        return openRecentMenu;
    }

    private Menu createPreferencesMenu() {
        Menu preferencesMenu = new Menu("Preferences");
        Menu themeMenu = new Menu("Theme");

        for (String themeName : ThemeManager.getAvailableThemes()) {
            MenuItem themeItem = new MenuItem(themeName);
            themeItem.setOnAction(event -> ThemeManager.applyThemeByName(themeName));
            themeMenu.getItems().add(themeItem);
        }

        preferencesMenu.getItems().addAll(
            new MenuItem("Settings"),
            themeMenu
        );

        return preferencesMenu;
    }

    private Menu createDeeplyNestedMenu() {
        return new Menu("Very...", null,
            new Menu("Very...", null,
                new Menu("Deeply", null,
                    new Menu("Nested", null,
                        new MenuItem("Menu")
                    )
                )
            )
        );
    }

    private MenuItem createItem(String text, Feather icon, KeyCombination accelerator) {
        MenuItem item = new MenuItem(text);
        if (icon != null) {
            item.setGraphic(new FontIcon(icon));
        }
        if (accelerator != null) {
            item.setAccelerator(accelerator);
        }
        return item;
    }

    private CheckMenuItem createCheckMenuItem(String text, Feather icon, KeyCombination accelerator) {
        CheckMenuItem item = new CheckMenuItem(text);
        if (icon != null) {
            item.setGraphic(new FontIcon(icon));
        }
        if (accelerator != null) {
            item.setAccelerator(accelerator);
        }
        return item;
    }

    private RadioMenuItem createRadioMenuItem(String text, Material2OutlinedAL icon, boolean selected) {
        RadioMenuItem item = new RadioMenuItem(text);
        item.setGraphic(new FontIcon(icon));
        item.setSelected(selected);
        return item;
    }

    private void runCode() {
        String editorContent = mainPresenter.getMonacoPresenter().getEditorContent();
        String language = mainPresenter.getMonacoPresenter().getEditorLanguage();

        // Use a default language if null
        if (language == null) {
            language = "plaintext";
        }

        String fileExtension = getFileExtension(language);

        try {
            Path tempFile = Files.createTempFile("cody_ide_", fileExtension);
            Files.write(tempFile, editorContent.getBytes());
            tempFileNames.add(tempFile.toString());
            System.out.println("Code saved to temporary file: " + tempFile);

            // Execute the code using the workspace terminal
            String command = getExecutionCommand(language, tempFile.toString());
            mainPresenter.getTerminalPresenter().writeAndExecuteCommand(command);
        } catch (IOException e) {
            e.printStackTrace();
            showErrorDialog("Error", "An error occurred while running the code", e.getMessage());
        }
    }

    private void showErrorDialog(String title, String header, String content) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private String getFileExtension(String language) {
        switch (language.toLowerCase()) {
            case "python":
                return ".py";
            case "java":
                return ".java";
            case "plaintext":
            default:
                return ".txt";
        }
    }

    private String getExecutionCommand(String language, String filePath) {
        switch (language.toLowerCase()) {
            case "python":
                return "python " + filePath;
            case "java":
                return "java " + filePath;
            case "plaintext":
            default:
                return "cat " + filePath; // or "type " + filePath on Windows
        }
    }

    public String getMostRecentTempFileName() {
        if (tempFileNames.isEmpty()) {
            return null;
        }
        return tempFileNames.get(tempFileNames.size() - 1);
    }
}

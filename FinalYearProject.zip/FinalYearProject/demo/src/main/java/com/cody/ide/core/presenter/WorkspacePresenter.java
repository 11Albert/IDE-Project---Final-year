package com.cody.ide.core.presenter;

import com.cody.ide.core.view.WorkspaceView;
import com.cody.ide.core.component.CodeEditor.MonacoPresenter;
import com.cody.ide.core.component.Terminal.TerminalPresenter;

public class WorkspacePresenter {

    private WorkspaceView workspaceView;
    private MonacoPresenter monacoPresenter;
    private TerminalPresenter terminalPresenter;

    public WorkspacePresenter(WorkspaceView workspaceView) {
        this.workspaceView = workspaceView;
        initialize();
    }

    private void initialize() {
        monacoPresenter = new MonacoPresenter(workspaceView.getMonacoView());
        terminalPresenter = new TerminalPresenter(workspaceView.getTerminalView());
    }

    public WorkspaceView getWorkspaceView() {
        return workspaceView;
    }

    public MonacoPresenter getMonacoPresenter() {
        return monacoPresenter;
    }

    public TerminalPresenter getTerminalPresenter() {
        return terminalPresenter;
    }
}

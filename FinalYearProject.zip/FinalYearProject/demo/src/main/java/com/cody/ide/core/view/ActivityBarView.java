package com.cody.ide.core.view;

import javafx.geometry.Orientation;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;

public class ActivityBarView {

    private ToolBar root;
    private Button explorerButton;
    private Button searchButton;
    private Button accountButton;
    private Button manageButton;

    public ActivityBarView() {
        root = new ToolBar();
        root.setOrientation(Orientation.VERTICAL);

        explorerButton = createIconButton(Feather.FOLDER, "Explorer");
        searchButton = createIconButton(Feather.SEARCH, "Search");
        accountButton = createIconButton(Feather.USER, "Account");
        manageButton = createIconButton(Feather.SETTINGS, "Manage");

        // Add buttons to the root
        root.getItems().addAll(explorerButton, searchButton);

        // Spacer to push account and manage buttons to the bottom
        VBox spacer = new VBox();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        root.getItems().add(spacer);

        root.getItems().addAll(new Separator(Orientation.VERTICAL), accountButton, manageButton);
    }

    private Button createIconButton(Feather icon, String tooltipText) {
        Button button = new Button();
        button.setGraphic(new FontIcon(icon));
        button.setTooltip(new Tooltip(tooltipText));
        button.getStyleClass().add("icon-button");
        return button;
    }

    public ToolBar getRoot() {
        return root;
    }

    public Button getExplorerButton() {
        return explorerButton;
    }

    public Button getSearchButton() {
        return searchButton;
    }

    public Button getAccountButton() {
        return accountButton;
    }

    public Button getManageButton() {
        return manageButton;
    }
}

package com.cody.ide.core.view.ActivityPanel;

import com.cody.ide.core.component.SideBar.SidebarView;
import com.cody.ide.core.view.ActivityPanel.Explorer.ExplorerView;
import com.cody.ide.core.view.ActivityPanel.Search.SearchView;

import javafx.scene.Node;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;

public class ActivityPanelManager {

    private SidebarView sidebarView;
    private ExplorerView explorerView;
    private SearchView searchView;
    private Node currentView;

    public ActivityPanelManager(SidebarView sidebarView) {
        this.sidebarView = sidebarView;
        explorerView = new ExplorerView();
        searchView = new SearchView();
    }

    public void toggleExplorerView() {
        toggleView((Node) explorerView);
    }

    public void toggleSearchView() {
        toggleView((Node) searchView);
    }

    private void toggleView(Node view) {
        if (currentView == view) {
            sidebarView.getRoot().getItems().remove(view);
            currentView = null;
        } else {
            if (currentView != null) {
                sidebarView.getRoot().getItems().remove(currentView);
            }
            sidebarView.getRoot().getItems().add(0, view); // Add before the spacer
            currentView = view;
        }
    }

    public Node getCurrentView() {
        return currentView;
    }

    public ExplorerView getExplorerView() {
        return explorerView;
    }

    public SearchView getSearchView() {
        return searchView;
    }
}

package com.cody.ide.core.view.ActivityPanel.Explorer;

import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;

import java.io.File;
import java.util.Arrays;
import java.util.Comparator;

/**
 * ExplorerView class represents a file explorer UI component.
 */
public class ExplorerView extends VBox {

    private static final String EXPLORER_TITLE = "Explorer";
    private static final String SEARCH_PROMPT_TEXT = "Search files...";
    private static final String EXPLORER_VIEW_STYLE_CLASS = "explorer-view";
    private static final String EXPLORER_TITLE_STYLE_CLASS = "explorer-title";
    private static final String SEARCH_BOX_STYLE_CLASS = "search-box";

    private final TreeView<String> treeView;
    private final TreeItem<String> rootItem;
    private final TextField searchField;

    public ExplorerView() {
        rootItem = new TreeItem<>(EXPLORER_TITLE);
        treeView = new TreeView<>(rootItem);
        treeView.setShowRoot(false);

        Label titleLabel = new Label(EXPLORER_TITLE);
        titleLabel.getStyleClass().add(EXPLORER_TITLE_STYLE_CLASS);

        searchField = new TextField();
        searchField.setPromptText(SEARCH_PROMPT_TEXT);
        searchField.textProperty().addListener((observable, oldValue, newValue) -> filterTree(newValue));

        HBox searchBox = new HBox(5, new FontIcon(Feather.SEARCH), searchField);
        searchBox.getStyleClass().add(SEARCH_BOX_STYLE_CLASS);

        this.getChildren().addAll(titleLabel, searchBox, treeView);
        this.getStyleClass().add(EXPLORER_VIEW_STYLE_CLASS);
    }

    public void addFileToTree(File file) {
        TreeItem<String> fileItem = createTreeItem(file);
        insertSorted(rootItem, fileItem);
    }

    public void addFolderToTree(File folder) {
        TreeItem<String> folderItem = createTreeItem(folder);
        insertSorted(rootItem, folderItem);
        populateTreeItem(folderItem, folder);
    }

    private TreeItem<String> createTreeItem(File file) {
        FontIcon icon = new FontIcon(file.isDirectory() ? Feather.FOLDER : Feather.FILE);
        TreeItem<String> item = new TreeItem<>(file.getName(), icon);
        item.setExpanded(file.isDirectory());
        return item;
    }

    private void populateTreeItem(TreeItem<String> item, File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            Arrays.sort(files, Comparator.comparing(File::isDirectory).reversed().thenComparing(File::getName));
            for (File file : files) {
                TreeItem<String> childItem = createTreeItem(file);
                insertSorted(item, childItem);
                if (file.isDirectory()) {
                    populateTreeItem(childItem, file);
                }
            }
        }
    }

    private void insertSorted(TreeItem<String> parent, TreeItem<String> child) {
        boolean isDirectory = ((FontIcon) child.getGraphic()).getIconCode() == Feather.FOLDER;
        int index = 0;
        for (TreeItem<String> sibling : parent.getChildren()) {
            boolean siblingIsDirectory = ((FontIcon) sibling.getGraphic()).getIconCode() == Feather.FOLDER;
            if (isDirectory && !siblingIsDirectory) {
                break;
            }
            if ((isDirectory == siblingIsDirectory) && child.getValue().compareTo(sibling.getValue()) < 0) {
                break;
            }
            index++;
        }
        parent.getChildren().add(index, child);
    }

    private void filterTree(String searchText) {
        filterItem(rootItem, searchText.toLowerCase());
        rootItem.setExpanded(true);
    }

    private boolean filterItem(TreeItem<String> item, String searchText) {
        if (item.getChildren().isEmpty()) {
            boolean matches = item.getValue().toLowerCase().contains(searchText);
            item.setExpanded(matches);
            return matches;
        }

        boolean matches = false;
        for (TreeItem<String> child : item.getChildren()) {
            matches |= filterItem(child, searchText);
        }
        item.setExpanded(matches);
        return matches;
    }
}

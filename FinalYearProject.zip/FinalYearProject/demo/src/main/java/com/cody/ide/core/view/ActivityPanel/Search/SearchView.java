package com.cody.ide.core.view.ActivityPanel.Search;

import javafx.scene.control.TextField;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;

public class SearchView extends VBox {

    private TextField searchField;
    private ListView<String> resultsList;

    public SearchView() {
        searchField = new TextField();
        searchField.setPromptText("Search...");

        resultsList = new ListView<>();
        // Sample data for the search results
        resultsList.getItems().addAll("Result 1", "Result 2", "Result 3");

        this.getChildren().addAll(searchField, resultsList);
    }
}

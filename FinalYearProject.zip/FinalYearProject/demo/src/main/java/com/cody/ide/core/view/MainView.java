package com.cody.ide.core.view;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class MainView {

    private BorderPane root;
    private ActivityBarView activityBarView;
    private TopBarView topBarView;
    private StatusBarView statusBarView;
    private WorkspaceView workspaceView;

    public MainView() {
        root = new BorderPane();
        activityBarView = new ActivityBarView();
        topBarView = new TopBarView();
        statusBarView = new StatusBarView();
        workspaceView = new WorkspaceView();

        VBox leftPane = new VBox();
        leftPane.getChildren().addAll(activityBarView.getRoot(), statusBarView.getRoot());
        VBox.setVgrow(activityBarView.getRoot(), Priority.ALWAYS);

        // Set the top bar, left pane, and center content in the root layout
        root.setTop(topBarView.getRoot());
        root.setLeft(leftPane);
        root.setCenter(workspaceView.getRoot());
        root.setBottom(statusBarView.getRoot());
    }

    public BorderPane getRoot() {
        return root;
    }

    public ActivityBarView getActivityBarView() {
        return activityBarView;
    }

    public TopBarView getTopBarView() {
        return topBarView;
    }

    public StatusBarView getStatusBarView() {
        return statusBarView;
    }

    public WorkspaceView getWorkspaceView() {
        return workspaceView;
    }
}
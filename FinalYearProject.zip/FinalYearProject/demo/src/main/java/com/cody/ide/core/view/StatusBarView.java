package com.cody.ide.core.view;

import javafx.geometry.Orientation;
import javafx.scene.control.Label;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;

public class StatusBarView {

    private ToolBar root;
    private Label statusLabel;

    public StatusBarView() {
        root = new ToolBar();
        root.setOrientation(Orientation.HORIZONTAL);
        root.getStyleClass().add("status-bar");
        statusLabel = new Label("Ready");

        // Add the status label to the root
        root.getItems().add(statusLabel);
    }

    public ToolBar getRoot() {
        return root;
    }

    public void setStatus(String status) {
        statusLabel.setText(status);
    }
}

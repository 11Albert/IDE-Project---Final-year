package com.cody.ide.core.view;

import javafx.scene.control.MenuBar;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class TopBarView {

    private VBox root;
    private MenuBar menuBar;
    private ToolBar toolBar;

    public TopBarView() {
        root = new VBox();
        menuBar = new MenuBar();
        toolBar = new ToolBar();
        toolBar.getStyleClass().add("top-bar"); // Add custom style class


        // Add menu bar and toolbar to the root
        root.getChildren().addAll(menuBar, toolBar);

        // Allow the toolbar to grow horizontally
        VBox.setVgrow(toolBar, Priority.ALWAYS);
    }

    public VBox getRoot() {
        return root;
    }

    public MenuBar getMenuBar() {
        return menuBar;
    }

    public ToolBar getToolBar() {
        return toolBar;
    }

    public void setToolBarVisible(boolean visible) {
        toolBar.setVisible(visible);
        toolBar.setManaged(visible);
    }
}

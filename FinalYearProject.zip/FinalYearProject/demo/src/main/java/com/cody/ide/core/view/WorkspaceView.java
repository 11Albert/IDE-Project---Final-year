package com.cody.ide.core.view;

import com.cody.ide.core.component.SideBar.SidebarView;
import com.cody.ide.core.component.CodeEditor.MonacoView;
import com.cody.ide.core.component.Terminal.TerminalView;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Priority;

public class WorkspaceView {

    private SplitPane root;
    private SidebarView sidebarView;
    private SplitPane middleSection;
    private VBox topMiddleSection;
    private VBox bottomMiddleSection;
    private VBox rightSection; // Kept for future use
    private MonacoView monacoView;
    private TerminalView terminalView;

    public WorkspaceView() {
        root = new SplitPane();
        sidebarView = new SidebarView();
        middleSection = new SplitPane();
        topMiddleSection = new VBox();
        bottomMiddleSection = new VBox();
        rightSection = new VBox(); // Kept for future use
        monacoView = new MonacoView();
        terminalView = new TerminalView();

        // Add MonacoView to the top middle section
        topMiddleSection.getChildren().add(monacoView.getRoot());
        VBox.setVgrow(monacoView.getRoot(), Priority.ALWAYS);

        // Add TerminalView to the bottom middle section and make it fill the space
        bottomMiddleSection.getChildren().add(terminalView.getRoot());
        VBox.setVgrow(terminalView.getRoot(), Priority.ALWAYS);

        // Configure the middle section to be split horizontally
        middleSection.setOrientation(javafx.geometry.Orientation.VERTICAL);
        middleSection.getItems().addAll(topMiddleSection, bottomMiddleSection);

        // Add only the middle section to the root split pane
        root.getItems().add(middleSection);

        // Set initial divider position for the middle section
        middleSection.setDividerPositions(0.7);
    }

    public SplitPane getRoot() {
        return root;
    }

    public SidebarView getSidebarView() {
        return sidebarView;
    }

    public VBox getTopMiddleSection() {
        return topMiddleSection;
    }

    public VBox getBottomMiddleSection() {
        return bottomMiddleSection;
    }

    public VBox getRightSection() {
        return rightSection;
    }

    public MonacoView getMonacoView() {
        return monacoView;
    }

    public TerminalView getTerminalView() {
        return terminalView;
    }

    public void showSidebar() {
        if (!root.getItems().contains(sidebarView.getRoot())) {
            root.getItems().add(0, sidebarView.getRoot());
            root.setDividerPositions(0.2);
        }
    }

    public void hideSidebar() {
        root.getItems().remove(sidebarView.getRoot());
    }

    // Method to show the right section when needed in the future
    public void showRightSection() {
        if (!root.getItems().contains(rightSection)) {
            root.getItems().add(rightSection);
            root.setDividerPositions(0.8);
        }
    }

    // Method to hide the right section
    public void hideRightSection() {
        root.getItems().remove(rightSection);
    }
}

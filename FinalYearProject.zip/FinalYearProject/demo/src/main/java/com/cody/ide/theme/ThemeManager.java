package com.cody.ide.theme;

import atlantafx.base.theme.*;
import javafx.scene.Scene;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ThemeManager {

    private static final String SYSTEM_CONFIG_PATH = "/config/system-config.yaml";
    private static final String USER_CONFIG_PATH = System.getProperty("user.home") + "/.config/cody/config.yaml";

    private static Theme currentTheme;
    private static List<Scene> activeScenes = new ArrayList<>();

    static {
        loadConfigurations();
    }

    public static void applyInitialTheme(Scene scene) {
        if (currentTheme == null) {
            loadConfigurations();
        }
        applyTheme(scene);
        activeScenes.add(scene);
    }

    public static void applyThemeByName(String themeName) {
        System.out.println("Applying theme: " + themeName);
        currentTheme = getThemeFromName(themeName);
        System.out.println("Current theme set to: " + currentTheme.getClass().getSimpleName());
        saveUserConfiguration();
        reapplyThemeToAllScenes();
    }

    public static List<String> getAvailableThemes() {
        return List.of("PrimerLight", "PrimerDark", "NordLight", "NordDark", "CupertinoLight", "CupertinoDark", "Dracula");
    }

    private static void applyTheme(Scene scene) {
        scene.getStylesheets().clear();
        scene.getStylesheets().add(currentTheme.getUserAgentStylesheet());
        String cssPath = ThemeManager.class.getResource("/themes/styles.css").toExternalForm();
        System.out.println("Loading custom CSS from: " + cssPath);
        scene.getStylesheets().add(cssPath);
    }

    private static void reapplyThemeToAllScenes() {
        for (Scene scene : activeScenes) {
            applyTheme(scene);
        }
    }

    private static void loadConfigurations() {
        try (InputStream systemConfigStream = ThemeManager.class.getResourceAsStream(SYSTEM_CONFIG_PATH)) {
            if (systemConfigStream == null) {
                throw new RuntimeException("System configuration file not found: " + SYSTEM_CONFIG_PATH);
            }
            Map<String, Object> systemConfig = new Yaml().load(systemConfigStream);

            File userConfigFile = new File(USER_CONFIG_PATH);
            if (userConfigFile.exists()) {
                try (InputStream userConfigStream = new FileInputStream(userConfigFile)) {
                    Map<String, Object> userConfig = new Yaml().load(userConfigStream);
                    currentTheme = getThemeFromName((String) userConfig.getOrDefault("defaultTheme", systemConfig.get("defaultTheme")));
                }
            } else {
                currentTheme = getThemeFromName((String) systemConfig.get("defaultTheme"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            currentTheme = new PrimerLight(); // Fallback to default theme
        }
    }

    private static void saveUserConfiguration() {
        try {
            Files.createDirectories(Paths.get(USER_CONFIG_PATH).getParent());

            DumperOptions options = new DumperOptions();
            options.setIndent(2);
            options.setPrettyFlow(true);
            options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);

            Yaml yaml = new Yaml(options);
            try (FileWriter writer = new FileWriter(USER_CONFIG_PATH)) {
                yaml.dump(Map.of("defaultTheme", currentTheme.getClass().getSimpleName()), writer);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Theme getThemeFromName(String themeName) {
        switch (themeName) {
            case "PrimerDark":
                return new PrimerDark();
            case "NordLight":
                return new NordLight();
            case "NordDark":
                return new NordDark();
            case "CupertinoLight":
                return new CupertinoLight();
            case "CupertinoDark":
                return new CupertinoDark();
            case "Dracula":
                return new Dracula();
            case "PrimerLight":
            default:
                return new PrimerLight();
        }
    }
}

module com.cody.ide {
    requires transitive javafx.graphics;
    requires transitive javafx.controls;
    requires transitive javafx.fxml;
    requires eu.mihosoft.monacofx;
    requires tiwulfx;
    requires tiwulfx.dock;
    requires pk.jeditermfx.app;
    requires pk.jeditermfx.core;
    requires pk.jeditermfx.ui;
    requires org.jetbrains.annotations;
    requires pty4j;
    requires org.slf4j;
    requires atlantafx.base;
    requires org.yaml.snakeyaml;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.ikonli.feather;
    requires org.kordamp.ikonli.material2;
    requires net.datafaker;

    opens com.cody.ide to javafx.fxml;
    exports com.cody.ide;
    exports com.cody.ide.core.presenter;
    exports com.cody.ide.core.view;
    exports com.cody.ide.theme;
    exports com.cody.ide.core.view.ActivityPanel;
    exports com.cody.ide.core.view.ActivityPanel.Search;
    exports com.cody.ide.core.view.ActivityPanel.Explorer;
    exports com.cody.ide.core.component.SideBar;
    exports com.cody.ide.core.component.CodeEditor;
}
